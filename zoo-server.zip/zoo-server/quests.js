/* UI списка квестов */
export function renderQuests(world,owner){
  if(!owner)return '<div class="letter">Войди в профиль ??, чтобы получать задания!</div>';
  const qs=(world.quests||[]).filter(q=>q.owner===owner.id);
  if(!qs.length)return '<div class="letter">Пока нет заданий — новые появятся скоро! ??</div>';
  return qs.map(q=>`<div class="letter">${q.emoji} ${q.text}<br><b>${Math.min(q.progress,q.n)}/${q.n}</b> · ?? ${q.reward} XP</div>`).join('');
}