# -*- coding: utf-8 -*-
# reset.py — сброс зоопарка. ВАЖНО: сначала остановите сервер (Ctrl+C)!
import json, os, glob, shutil, time

DATA='data'
print('1) ПОЛНЫЙ сброс — всё в backup, начнётся новый зоопарк')
print('2) Сброс УРОВНЕЙ — звери и рисунки остаются, но все снова 1 уровня')
print('3) Выход')
ch=input('Выбор: ').strip()

if ch=='1':
    if os.path.exists(DATA):
        bk=DATA+'_backup_'+time.strftime('%Y%m%d_%H%M%S')
        shutil.move(DATA,bk)
        print('✅ Старые данные уехали в папку:',bk)
    print('Теперь запустите: python server.py — зоопарк создастся заново.')
elif ch=='2':
    adir=os.path.join(DATA,'animals')
    for f in glob.glob(os.path.join(adir,'*.json')):
        a=json.load(open(f,encoding='utf-8'))
        a['level']=1; a['xp']=0
        json.dump(a,open(f,'w',encoding='utf-8'),ensure_ascii=False)
    wf=os.path.join(DATA,'world.json')
    if os.path.exists(wf):
        w=json.load(open(wf,encoding='utf-8'))
        w['unlocked']=['meadow','pond']
        json.dump(w,open(wf,'w',encoding='utf-8'),ensure_ascii=False)
    print('✅ Уровни сброшены. Запустите: python server.py')
else:
    print('Пока!')