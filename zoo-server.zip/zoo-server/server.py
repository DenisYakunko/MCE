# -*- coding: utf-8 -*-
import json, math, os, random, threading, time, shutil
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse

PORT=8080
DATA='data'; ADIR=os.path.join(DATA,'animals'); TDIR=os.path.join(DATA,'textures')
os.makedirs(ADIR,exist_ok=True); os.makedirs(TDIR,exist_ok=True)
WORLD_F=os.path.join(DATA,'world.json'); MAIL_F=os.path.join(DATA,'mailbox.json')
FEEDER=(2.2,-1.6); WORLD_R=36; HILL=(7,-13)
SHELTER=[(-13,5),(-11,4),(-15,6)]
DEF_COLOR={'lion':'#d9a066','fox':'#d4622a','rabbit':'#c9c9c9','custom':'#ffffff',
           'bear':'#8a5a33','elephant':'#9aa0a8','panda':'#f2f2f2','deer':'#b08050'}
LOCATIONS=[
 dict(id='meadow',name='Лужайка',x=0,z=0,r=7,unlock_cond='start',kind='meadow',zone='in'),
 dict(id='pond',name='Пруд',x=13,z=5,r=5,unlock_cond='start',kind='pond',zone='in'),
 dict(id='grove',name='Роща',x=-13,z=5,r=5,unlock_cond='level:2',kind='grove',zone='in'),
 dict(id='flowers',name='Цветочная поляна',x=-7,z=-13,r=4,unlock_cond='level:3',kind='flowers',zone='in'),
 dict(id='hill',name='Холмы',x=7,z=-13,r=5,unlock_cond='level:4',kind='hill',zone='in'),
 dict(id='forest',name='Дикий лес',x=0,z=30,r=6,unlock_cond='level:6',kind='forest',zone='out'),
 dict(id='alien',name='Долина НЛО',x=0,z=-30,r=5,unlock_cond='level:8',kind='alien',zone='out'),
 dict(id='gate2',name='Ворота в Зоопарк 2',x=-21,z=-21,r=5,unlock_cond='total:50',kind='gate2',zone='out'),
]
COND_TEXT={'start':'открыта сразу','level:2':'любой зверь достиг 2 уровня',
 'level:3':'любой зверь достиг 3 уровня','level:4':'любой зверь достиг 4 уровня',
 'level:6':'любой зверь достиг 6 уровня','level:8':'любой зверь достиг 8 уровня',
 'total:50':'сумма уровней ВСЕХ зверей ≥ 50'}
ACHIEVEMENTS=[
 ('first_star','🏅','Первая звезда: найти коллекционку'),
 ('star10','🌟','Звездочёт: собрать 10 коллекционок'),
 ('caretaker','💖','Заботливый: 10 действий заботы'),
 ('friend','🐾','Друг зверей: завести своего питомца'),
 ('level5','⭐','Наставник: твой зверь достиг 5 уровня'),
 ('explorer','🧭','Исследователь: коллекционки из 3 разных локаций'),
 ('quest5','📬','Почтальон: выполнить 5 заданий'),
]
def clamp(v,lo=0,hi=100):return max(lo,min(hi,v))
def dist(a,p):return math.hypot(a['x']-p[0],a['z']-p[1])

def season_now():
    m=time.localtime().tm_mon
    return {12:'winter',1:'winter',2:'winter',3:'spring',4:'spring',5:'spring',
            6:'summer',7:'summer',8:'summer',9:'autumn',10:'autumn',11:'autumn'}[m]
def season_cur(): return world.get('season_force') or season_now()
SEASON_NAME={'winter':'зима ❄️','spring':'весна 🌸','summer':'лето ☀️','autumn':'осень 🍂'}
SEASON_BLOOM={'spring':.85,'summer':1,'autumn':.35,'winter':0}
SEASON_GROW={'spring':1,'summer':1,'autumn':.85,'winter':.55}
def loc_life(L,t):
    kind=L['kind']; h=time.localtime().tm_hour; season=season_cur()
    dayf=1 if 7<=h<22 else .45
    life={}
    if kind in ('meadow','flowers'):
        cyc=.65+.35*math.sin(t/240)
        life['bloom']=round(max(0,SEASON_BLOOM[season]*dayf*cyc),2)
    if kind in ('grove','forest'):
        days=(t-world.get('day_started',t))/86400
        life['growth']=round(min(1,(.4+days/14)*SEASON_GROW[season]),2)
        if season=='winter': life['critters']=['🐦']
        elif h>=22 or h<7: life['critters']=['🦔','']
        else: life['critters']=['🐦','','']
        if season=='autumn': life['mushrooms']=3
    if kind=='pond':
        life['frozen']=1 if season=='winter' else 0
        if season in ('spring','summer') and 7<=h<22: life['frogs']=2
    return life

def new_animal(i,p=None):
    p=p or {}; kinds=[('lion','Лео'),('fox','Алиса'),('rabbit','Степа')]
    sp=p.get('species',kinds[i%3][0]); name=p.get('name') or kinds[i%3][1]
    ang=random.uniform(0,6.28); rr=random.uniform(0,7)
    a=dict(id=i,species=sp,name=name,
        color=p.get('color',DEF_COLOR.get(sp,'#d9a066')),
        speed=float(p.get('speed',1)),trait=p.get('trait','calm'),
        metabolism=round(random.uniform(.8,1.3),2),phase=round(random.uniform(0,6.28),2),
        tempo=1,level=1,xp=0,owner=None,owner_name=None,
        full=random.uniform(50,95),mood=random.uniform(50,95),
        health=100,energy=random.uniform(60,95),
        x=round(rr*math.cos(ang),2),z=round(rr*math.sin(ang),2),
        dir=random.uniform(0,6.28),state='walk',tx=None,tz=None,born=time.time())
    if p.get('texture'):
        a['species']='custom'; a['texture']=p['texture']
    return a

def migrate(a):
    for k,v in new_animal(a.get('id',0)).items(): a.setdefault(k,v)
    a.setdefault('owner',None); a.setdefault('owner_name',None)
    return a

world=dict(weather='sun',event=None,news=[],saved=time.time(),
           unlocked=['meadow','pond'],day_started=time.time(),season_cur=None,collectibles=[])
mail=[]; animals={}

def news(t):
    world['news'].append(dict(t=time.time(),text=t)); world['news']=world['news'][-20:]

def save_animal(a): json.dump(a,open(os.path.join(ADIR,f"{a['id']}.json"),'w',encoding='utf-8'),ensure_ascii=False)
def save_world():
    world['saved']=time.time()
    json.dump(world,open(WORLD_F,'w',encoding='utf-8'),ensure_ascii=False)
    json.dump(mail,open(MAIL_F,'w',encoding='utf-8'),ensure_ascii=False)

OWNERS_F=os.path.join(DATA,'owners.json')
owners={}
OWNER_COLORS=['#e56ba5','#5bc0de','#e8a33c','#58b368','#9b59b6','#e74c3c','#1abc9c','#f39c12']
def load_owners():
    global owners
    if os.path.exists(OWNERS_F):
        try: owners={o['id']:o for o in json.load(open(OWNERS_F,encoding='utf-8'))}
        except Exception: pass
def save_owners():
    json.dump(list(owners.values()),open(OWNERS_F,'w',encoding='utf-8'),ensure_ascii=False)
def pub(o): return dict(id=o.get('id'),name=o.get('name'),color=o.get('color'),
                        stars=o.get('stars',0),badges=o.get('badges',[]))
def do_owner(b,action):
    name=(b.get('name') or '').strip()[:20]; pin=(b.get('pin') or '').strip()[:8]
    if not name or not pin: return {'ok':False,'err':'введите имя и PIN'}
    if action=='login':
        o=next((o for o in owners.values() if o['name'].lower()==name.lower()),None)
        if not o or o['pin']!=pin: return {'ok':False,'err':'неверное имя или PIN'}
        return {'ok':True,'owner':pub(o)}
    if any(o['name'].lower()==name.lower() for o in owners.values()):
        return {'ok':False,'err':'taken'}
    i=(max(owners)+1) if owners else 0
    o=dict(id=i,name=name,pin=pin,color=OWNER_COLORS[i%len(OWNER_COLORS)],
           stars=0,badges=[],stats=dict(collected=0,actions=0,quests=0,locs=[]))
    owners[i]=o; save_owners()
    news(f'👤 Новый владелец: {name}!')
    return {'ok':True,'owner':pub(o)}

def check_ach(o):
    st=o.setdefault('stats',dict(collected=0,actions=0,quests=0,locs=[]))
    badges=o.setdefault('badges',[])
    def grant(i):
        if i in badges: return
        badges.append(i)
        meta=next(a for a in ACHIEVEMENTS if a[0]==i)
        news(f'🏅 {o["name"]}: достижение «{meta[2]}»!')
        m=dict(id=int(time.time()*1000)+len(badges),ts=time.time(),kind='mail',read=False,
               owner=o['id'],text=f'🏅 Новое достижение: «{meta[2]}»! Так держать!')
        m['from']='Директор зоопарка'; mail.append(m)
    if st.get('collected',0)>=1: grant('first_star')
    if st.get('collected',0)>=10: grant('star10')
    if st.get('actions',0)>=10: grant('caretaker')
    if st.get('quests',0)>=5: grant('quest5')
    if len(st.get('locs',[]))>=3: grant('explorer')
    if any(a.get('owner')==o['id'] for a in animals.values()): grant('friend')
    if any(a.get('owner')==o['id'] and a['level']>=5 for a in animals.values()): grant('level5')

def cond_ok(cond):
    if cond=='start': return True
    if cond.startswith('level:'):
        return any(a['level']>=int(cond.split(':')[1]) for a in animals.values())
    if cond.startswith('total:'):
        return sum(a['level'] for a in animals.values())>=int(cond.split(':')[1])
    return False
def refresh_unlocks(quiet=False):
    for L in LOCATIONS:
        if L['id'] not in world['unlocked'] and cond_ok(L['unlock_cond']):
            world['unlocked'].append(L['id'])
            if not quiet: news(f'🎉 Открылась локация: {L["name"]}!')
def add_xp(a,n):
    n=max(1,int(n/(1+(a['level']-1)*0.08)))
    a['xp']+=n; nl=1+a['xp']//100
    if nl>a['level']:
        a['level']=nl; news(f"{a['name']} достиг уровня {nl}! ⬆️"); refresh_unlocks()
        if a.get('owner') is not None:
            o=owners.get(a['owner'])
            if o: check_ach(o); save_owners()

def clean_mail():
    now=time.time()
    mail[:]=[m for m in mail if not (
        (m.get('done') and now-m.get('done_ts',now)>12*3600) or
        (m.get('kind')=='mail' and m.get('read') and now-m.get('ts',now)>2*86400))]

def load():
    global mail
    if os.path.exists(WORLD_F): world.update(json.load(open(WORLD_F,encoding='utf-8')))
    world.setdefault('collectibles',[])
    world.setdefault('day_started',time.time())   # фикс «день 20674»
    if os.path.exists(MAIL_F): mail=json.load(open(MAIL_F,encoding='utf-8'))
    for f in os.listdir(ADIR):
        if f.endswith('.json'):
            try: a=migrate(json.load(open(os.path.join(ADIR,f),encoding='utf-8')))
            except Exception: continue
            animals[a['id']]=a
    if not animals and world.get('animals'):
        for a in world.get('animals'):
            a=migrate(a); animals[a['id']]=a; save_animal(a)
    if not animals:
        for i in range(3): a=new_animal(i); animals[i]=a; save_animal(a)
    if not mail:
        m=dict(id=1,ts=time.time(),kind='mail',read=False,
            text='Добро пожаловать! Выполняйте задания — звери получают опыт и открывают новые места.')
        m['from']='Смотритель зоопарка'; mail.append(m)
    load_owners()
    for a in animals.values():
        if a.get('owner') is not None and not a.get('owner_name'):
            o=owners.get(a['owner']); a['owner_name']=o['name'] if o else None
    world['season_cur']=season_cur()
    refresh_unlocks(quiet=True)
    away=time.time()-world.get('saved',time.time())
    if away>120:
        mins=int(away//60)
        for a in animals.values():
            a['full']=clamp(a['full']-mins*.25); a['energy']=clamp(a['energy']+mins*.3); a['state']='walk'
        news(f'Пока никого не было ({mins} мин), животные жили своей жизнью')

FUN_MAIL=[
 ('Лесной почтальон','Говорят, если погладить зверя три раза подряд, день будет удачным!'),
 ('Инопланетяне 👽','Мы пролетали мимо. У вас милые звери.'),
 ('Дедушка Барсук','В моё время холмы были выше!'),
 ('Сорока Белла','Я видела, как кто-то прятал семечки у пруда.'),
]
LEVEL_MAIL={5:'Твой зверь уже не малыш! Он стал устойчивее к непогоде.',
 10:'Поздравляем! Твой зверь — настоящий ветеран зоопарка.',
 15:'Твой зверь начал дружить с другими.',
 20:'ЛЕГЕНДА! Твой зверь вошёл в историю зоопарка.'}
def make_mail():
    zs=list(animals.values())
    if not zs: return
    a=random.choice(zs); q=None
    if a['full']<45: q=dict(action='feed',text=f"{a['name']} проголодался! Покормите его.")
    elif a['mood']<45: q=dict(action='pet',text=f"{a['name']} грустит. Погладьте его!")
    elif a['health']<60: q=dict(action='heal',text=f"{a['name']} прихворал. Полечите его.")
    if q:
        m=dict(id=int(time.time()*1000),ts=time.time(),kind='quest',
               done=False,read=False,animal=a['id'],reward=20,**q)
        m['from']='Смотритель зоопарка'; m['owner']=a.get('owner'); mail.append(m)
    elif a['level'] in LEVEL_MAIL and not any(x.get('text')==LEVEL_MAIL[a['level']] for x in mail):
        m=dict(id=int(time.time()*1000),ts=time.time(),text=LEVEL_MAIL[a['level']],kind='mail',read=False)
        m['from']='Директор зоопарка'; mail.append(m)
    else:
        frm,txt=random.choice(FUN_MAIL)
        m=dict(id=int(time.time()*1000),ts=time.time(),text=txt,kind='mail',read=False)
        m['from']=frm; mail.append(m)
    del mail[:-40]

BASE={'feed':lambda a:(a.update(full=clamp(a['full']+25)),news(f"Вы покормили: {a['name']} 🍖")),
      'pet':lambda a:(a.update(mood=clamp(a['mood']+20)),news(f"Вы погладили: {a['name']} 💛")),
      'heal':lambda a:(a.update(health=clamp(a['health']+30)),news(f"Вы полечили: {a['name']} 💊"))}
XP={'feed':5,'pet':3,'heal':8}

def do_action(b):
    a=animals.get(b.get('id')); t=b.get('type')
    if not a: return {'ok':False}
    o=owners.get(b.get('owner')) if b.get('owner') is not None else None
    if t=='visit':
        a['mood']=clamp(a['mood']+10); save_animal(a); return {'ok':True}
    if t not in BASE: return {'ok':False}
    BASE[t](a); add_xp(a,XP[t])
    if o:
        st=o.setdefault('stats',dict(collected=0,actions=0,quests=0,locs=[]))
        st['actions']=st.get('actions',0)+1
        check_ach(o); save_owners()
    for q in mail:
        if q.get('kind')=='quest' and not q.get('done') and q.get('action')==t and q.get('animal')==a['id']:
            q['done']=True; q['done_ts']=time.time()
            add_xp(a,q.get('reward',20)); news(f'Задание выполнено ✅ (+{q.get("reward",20)} XP)')
            qo=owners.get(q.get('owner')) if q.get('owner') is not None else None
            if qo:
                st=qo.setdefault('stats',dict(collected=0,actions=0,quests=0,locs=[]))
                st['quests']=st.get('quests',0)+1
                check_ach(qo); save_owners()
    save_animal(a); return {'ok':True}

def do_add(b):
    if len(animals)>=12: return {'ok':False,'err':'Зоопарк полон! (макс. 12)'}
    i=(max(animals)+1) if animals else 0
    a=new_animal(i,b); a['owner']=b.get('owner')
    o=owners.get(a['owner']) if a['owner'] is not None else None
    a['owner_name']=o['name'] if o else None
    animals[i]=a; save_animal(a)
    news(f'Пополнение! {a["name"]} теперь живёт в зоопарке 🎉'); refresh_unlocks()
    if o: check_ach(o); save_owners()
    return {'ok':True,'id':i}

def do_reset(mode):
    if mode=='full':
        if os.path.exists(DATA):
            bk=DATA+'_backup_'+time.strftime('%Y%m%d_%H%M%S')
            os.rename(DATA,bk); print('backup ->',bk)
        os.makedirs(ADIR,exist_ok=True); os.makedirs(TDIR,exist_ok=True)
        animals.clear(); mail.clear(); world.clear()
        world.update(dict(weather='sun',event=None,news=[],saved=time.time(),
                          unlocked=['meadow','pond'],day_started=time.time(),collectibles=[]))
        for i in range(3):
            a=new_animal(i); animals[i]=a; save_animal(a)
        m=dict(id=1,ts=time.time(),kind='mail',read=False,
            text='Добро пожаловать! Зоопарк начал новую жизнь.')
        m['from']='Смотритель зоопарка'; mail.append(m)
        news('🌱 Зоопарк начал новую жизнь!')
    else:
        for a in animals.values():
            a['level']=1; a['xp']=0
            a['full']=random.uniform(50,95); a['mood']=random.uniform(50,95)
            a['health']=100; a['energy']=random.uniform(60,95)
            save_animal(a)
        world['unlocked']=['meadow','pond']
        news('🙂 Пересменка: все звери снова 1 уровня, локации закрыты.')
    save_world()
    return {'ok':True}

EVENTS=[
 ('wind','Поднялся сильный ветер!',-10,-8),
 ('rain','Небо потемнело — хлынул ливень!',-8,-5),
 ('flood','ТРЕВОГА: наводнение!',-15,-12),
 ('ufo','НЛО над зоопарком!',-5,-3),
 ('beast','Из леса прибежал СТРАШНЫЙ ЗВЕРЬ!',-20,-15),
 ('eclipse','🌑 Затмение! Стало темно…',-12,-10),
 ('tornado','🌪️ Торнадо! Всех сдувает!',-18,-14),
 ('meteor','☄️ Метеорит! Паника!',-25,-20),
 ('harvest','🎃 Праздник урожая!',+15,+10),
 ('magic','✨ Волшебная ночь! Звери сияют.',+20,+15),
]
EVENT_END={'wind':'Ветер стих.','rain':'Дождь кончился.','flood':'Вода сошла!',
 'ufo':'НЛО улетело. 👽','beast':'Страшный зверь убежал. Фух!','eclipse':'Свет вернулся.',
 'tornado':'Торнадо ушёл.','meteor':'Метеорит пролетел мимо.','harvest':'Праздник удался!',
 'magic':'Волшебство рассеялось.'}
COLL_EMO={'meadow':'⭐','flowers':'🌸','pond':'🐚','grove':'🌰','forest':'🌰',
          'hill':'💎','alien':'🔮','gate2':'🗝️'}

def feeder_spot(a): k=a['id']; return (FEEDER[0]+(k%3-1)*.6, FEEDER[1]+(k//3)*.6)
def pick_target(a):
    if random.random()<.4:
        ang=random.uniform(0,6.28); rr=random.uniform(2,18.0)
        return rr*math.cos(ang), rr*math.sin(ang)
    opts=[L for L in LOCATIONS if L['id'] in world['unlocked']]
    if a['trait']=='shy': opts=[LOCATIONS[0]]
    elif a['trait']=='calm' and random.random()<.5:
        opts=[L for L in opts if L['zone']=='in'] or opts
    L=random.choice(opts)
    ang=random.uniform(0,6.28); rr=random.uniform(0,L['r']-.4)
    return L['x']+rr*math.cos(ang), L['z']+rr*math.sin(ang)

def effect_power(a): return max(0.4, 1 - a['level']*0.03)

def tick():
    n=0
    while True:
        time.sleep(1); n+=1; t=time.time()
        h=time.localtime().tm_hour
        night=h>=22 or h<7; lunch=13<=h<14
        season=season_cur()
        if season!=world.get('season_cur'):
            world['season_cur']=season
            news(f'Наступила {SEASON_NAME[season]}!')
        ev=world['event']
        if ev and t>ev['until']:
            if ev['kind'] in ('wind','rain','flood'): world['weather']='sun'
            news(EVENT_END[ev['kind']])
            if ev['kind']=='rain':
                for a in animals.values(): a['mood']=clamp(a['mood']+8)
                news('Выглянула радуга 🌈')
            world['event']=None
        elif not world['event'] and random.random()<1/1200:
            kind,text,md,mm=random.choice(EVENTS)
            if kind in ('wind','rain','flood'): world['weather']=kind
            world['event']=dict(kind=kind,until=t+random.uniform(40,90),md=md,mm=mm)
            news(text)
            if kind in ('harvest','magic'):
                for a in animals.values():
                    a['full']=clamp(a['full']+max(0,-md*effect_power(a)))
                    a['mood']=clamp(a['mood']+max(0,-mm*effect_power(a)))
        if random.random()<1/180: make_mail()
        cs=world.setdefault('collectibles',[])
        cs[:]=[c for c in cs if t-c['born']<120]
        if len(cs)<2 and random.random()<1/1200:
            L=random.choice([x for x in LOCATIONS if x['id'] in world['unlocked']])
            e=COLL_EMO.get(L['kind'],'⭐')
            if L['kind']=='flowers' and season not in ('spring','summer'): e='⭐'
            if L['kind']=='forest' and season=='autumn': e='🍄'
            ang=random.uniform(0,6.28); rr=random.uniform(0,L['r']-.5)
            cs.append(dict(id=int(t*1000),x=round(L['x']+rr*math.cos(ang),2),
                           z=round(L['z']+rr*math.sin(ang),2),e=e,loc=L['id'],locname=L['name'],born=t))
        ev=world['event']; scary=bool(ev and ev['kind'] in ('beast','ufo','eclipse','tornado','meteor'))
        for a in animals.values():
            m=a.get('metabolism',1)
            a['full']=clamp(a['full']-.05*m)
            if a['state']=='sleep':
                a['energy']=clamp(a['energy']+(.2 if night else .1))
                if a['energy']>95 and not night: a['state']='walk'
            else:
                a['energy']=clamp(a['energy']-.025*m)
                if world['weather']=='rain': a['energy']=clamp(a['energy']-.015)
                if season=='winter': a['energy']=clamp(a['energy']-.008)
            if a['full']<20 or a['energy']<10: a['health']=clamp(a['health']-.04)
            elif a['full']>60 and a['mood']>60: a['health']=clamp(a['health']+.005)
            if world['weather']=='flood':
                if dist(a,HILL)>2.5: a['health']=clamp(a['health']-.04)
                else: a['health']=clamp(a['health']+.01)
            if ev and ev['kind'] not in ('harvest','magic'):
                pwr=effect_power(a)
                a['mood']=clamp(a['mood']+ev['md']*pwr*0.05)
                a['energy']=clamp(a['energy']+ev['mm']*pwr*0.03)
            base=40 if (scary or world['weather']!='sun') else 75
            a['mood']=clamp(a['mood']+(base-a['mood'])*.002)
            if a['state']=='sleep':
                if night: continue
                if a['energy']>90: a['state']='walk'
                continue
            if a['state'] in ('play','idle'):
                if t>a.get('pu',0): a['state']='walk'
                continue
            if night and a['state']!='sleep' and random.random()<.05:
                a['state']='sleep'; continue
            if scary or (a['trait']=='shy' and world['weather']!='sun'):
                a['tx'],a['tz']=math.cos(a['phase'])*1.2,math.sin(a['phase'])*1.2; a['state']='flee'
            elif ev and ev['kind']=='ufo' and a['trait']=='curious':
                a['tx'],a['tz']=math.cos(a['phase'])*3.5,math.sin(a['phase'])*3.5
            elif world['weather'] in ('rain','wind') and a['trait']!='curious' and random.random()<.8:
                sx,sz=random.choice(SHELTER); a['tx'],a['tz']=sx+math.cos(a['phase'])*.6,sz+math.sin(a['phase'])*.6
            elif world['weather']=='flood':
                a['tx'],a['tz']=HILL[0]+math.cos(a['phase'])*1.5,HILL[1]+math.sin(a['phase'])*1.5
            elif a['state']=='eat':
                a['full']=clamp(a['full']+1)
                if a['full']>90: a['state']='walk'; a['tx']=a['tz']=None
                continue
            elif a['full']<30 or (lunch and a['full']<85):
                fs=feeder_spot(a); a['tx'],a['tz']=fs
                if dist(a,fs)<.3: a['state']='eat'; continue
            elif a['energy']<25:
                a['state']='sleep'; continue
            elif (a['trait']=='playful' or a['mood']>85) and random.random()<1/400:
                a['state']='play'; a['pu']=t+random.uniform(3,6); continue
            elif random.random()<1/80:
                a['state']='idle'; a['pu']=t+random.uniform(2,6); continue
            elif a['tx'] is None or dist(a,(a['tx'],a['tz']))<.2:
                a['tx'],a['tz']=pick_target(a)
                a['tempo']=round(random.uniform(.6,1.5),2)
            speed=(0.9 if a['state']=='flee' else .35)*a.get('speed',1)*a.get('tempo',1)
            if world['weather']=='wind' and a['state']!='flee': speed*=.75
            dx,dz=a['tx']-a['x'],a['tz']-a['z']; d=math.hypot(dx,dz)
            if d>.15:
                a['dir']=math.atan2(dx,dz); a['x']+=dx/d*speed; a['z']+=dz/d*speed
            a['x']=clamp(a['x'],-WORLD_R,WORLD_R); a['z']=clamp(a['z'],-WORLD_R,WORLD_R)
        for a in animals.values():
            for L in LOCATIONS:
                if L['id'] in world['unlocked'] and dist(a,(L['x'],L['z']))<L['r']:
                    lf=loc_life(L,t)
                    if lf.get('bloom',0)>.6:
                        a['mood']=clamp(a['mood']+.03); a['full']=clamp(a['full']+.015)
                    if lf.get('critters') and a['trait'] in ('curious','playful'):
                        a['mood']=clamp(a['mood']+.02)
                    break
        lst=list(animals.values())
        for i in range(len(lst)):
            for j in range(i+1,len(lst)):
                a,b=lst[i],lst[j]; dx,bz=b['x']-a['x'],b['z']-a['z']; d=math.hypot(dx,bz)
                if 1e-4<d<.7:
                    push=(.7-d)/2; dx/=d; bz/=d
                    a['x']-=dx*push; a['z']-=bz*push; b['x']+=dx*push; b['z']+=bz*push
        if n%30==0:
            for f in os.listdir(ADIR):
                if f.endswith('.json'):
                    try: aid=int(f[:-5])
                    except ValueError: continue
                    if aid not in animals:
                        try:
                            a=migrate(json.load(open(os.path.join(ADIR,f),encoding='utf-8')))
                            animals[aid]=a; news(f'Пополнение! {a["name"]} в зоопарке 🎉')
                        except Exception: pass
        if n%10==0:
            clean_mail()
            for a in animals.values(): save_animal(a)
            save_world()

class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        p=urlparse(self.path)
        if p.path=='/api/state':
            self._json(dict(animals=list(animals.values()),weather=world['weather'],
                event=world['event'],news=world['news'],mail=mail,
                season=season_cur(),
                collectibles=world.get('collectibles',[]),
                day_started=world.get('day_started'),
                goal=dict(total=sum(a['level'] for a in animals.values()),need=50),
                locations=[dict(L,unlocked=L['id'] in world['unlocked'],
                                cond_text=COND_TEXT.get(L['unlock_cond'],''),
                                life=loc_life(L,time.time())) for L in LOCATIONS]))
        else: super().do_GET()
    def do_POST(self):
        p=urlparse(self.path)
        ct=self.headers.get('Content-Type','')
        if p.path=='/api/upload' and 'multipart/form-data' in ct:
            try:
                boundary=None
                for part in ct.split(';'):
                    part=part.strip()
                    if part.startswith('boundary='):
                        boundary=part[9:].strip('"'); break
                if not boundary:
                    self._json({'ok':False,'err':'нет boundary'}); return
                n=int(self.headers.get('Content-Length','0'))
                body=self.rfile.read(n) if n else b''
                if not body:
                    self._json({'ok':False,'err':'пустое тело'}); return
                sep=('--'+boundary).encode()
                found=None
                for chunk in body.split(sep):
                    if b'name="file"' in chunk[:500]:
                        found=chunk; break
                if not found:
                    self._json({'ok':False,'err':'поле file не найдено'}); return
                head_end=found.find(b'\r\n\r\n')
                if head_end<0:
                    self._json({'ok':False,'err':'плохой формат'}); return
                head=found[:head_end].decode('utf-8','replace')
                data=found[head_end+4:]
                if data.endswith(b'\r\n'): data=data[:-2]
                fn='draw.png'
                for ln in head.split('\r\n'):
                    if 'filename=' in ln:
                        for q in ln.split('filename=')[1].split(';'):
                            q=q.strip().strip('"')
                            if q: fn=q; break
                        break
                ext=os.path.splitext(fn)[1].lower()
                if ext not in ('.png','.jpg','.jpeg','.webp','.gif'): ext='.png'
                fname=f'{int(time.time()*1000)}{ext}'
                os.makedirs(TDIR,exist_ok=True)
                with open(os.path.join(TDIR,fname),'wb') as o: o.write(data)
                print('✅ сохранён рисунок:', fname, len(data),'байт')
                self._json({'ok':True,'texture':'data/textures/'+fname})
                return
            except Exception as e:
                print('❌ ошибка upload:', e)
                self._json({'ok':False,'err':str(e)})
                return
        n=int(self.headers.get('Content-Length','0'))
        b=json.loads(self.rfile.read(n) or b'{}')
        if p.path=='/api/action': self._json(do_action(b))
        elif p.path=='/api/add': self._json(do_add(b))
        elif p.path=='/api/collect':
            cid=b.get('id')
            o=owners.get(b.get('owner')) if b.get('owner') is not None else None
            item=next((c for c in world.get('collectibles',[]) if c['id']==cid),None)
            if not item:
                self._json({'ok':False}); return
            world['collectibles'].remove(item)
            res={'ok':True}
            if o:
                st=o.setdefault('stats',dict(collected=0,actions=0,quests=0,locs=[]))
                st['collected']=st.get('collected',0)+1
                if item['loc'] not in st['locs']: st['locs'].append(item['loc'])
                o['stars']=o.get('stars',0)+1
                check_ach(o); save_owners()
                res['owner']=pub(o)
                news(f'{o["name"]} нашёл {item["e"]} в локации «{item["locname"]}»!')
            else:
                news(f'Кто-то нашёл {item["e"]}! Войди в профиль, чтобы копить звёзды.')
            save_world(); self._json(res)
        elif p.path=='/api/mail/read':
            for q in mail: q['read']=True
            save_world(); self._json({'ok':True})
        elif p.path=='/api/mail/clean':
            mail[:]=[m for m in mail if not m.get('done') and not (m.get('kind')=='mail' and m.get('read'))]
            save_world(); self._json({'ok':True})
        elif p.path=='/api/reset': self._json(do_reset(b.get('mode','levels')))
        elif p.path=='/api/owner': self._json(do_owner(b,b.get('action','login')))
        elif p.path=='/api/season':
            world['season_force']=b.get('season')
            save_world(); self._json({'ok':True})
        else: self.send_error(404)
    def _json(self,o):
        d=json.dumps(o,ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.end_headers(); self.wfile.write(d)
    def log_message(self,*a): pass

load()
threading.Thread(target=tick,daemon=True).start()
print(f'🦁 Зоопарк: http://localhost:{PORT} | анкета: /create.html | справка: /help.html')
try: ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
finally:
    for a in animals.values(): save_animal(a)
    save_world()